/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: cag.bg.segurospaso.vendors.vidamodular
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133990595815366942
    Date: 07/08/2025
    Time: 18:59
*/
import { IImporte } from './Importe';

export interface IProgresionEconomicaResponseAttributes {

  // identificadorDeOportunidad 
  identificadorDeOportunidad: number;
  // anho 
  anho: number;
  // ingresosConyuge 
  ingresosConyuge: IImporte;
  // ingresosViudedad 
  ingresosViudedad: IImporte;
  // ingresosOrfandad 
  ingresosOrfandad: IImporte;
  // ingresosOrfandadComplemento 
  ingresosOrfandadComplemento: IImporte;
  // ingresosInvalidez 
  ingresosInvalidez: IImporte;
  // ingresosActuales 
  ingresosActuales: IImporte;
  // perdidaDeIngresos 
  perdidaDeIngresos: IImporte;
  // capitalNecesario 
  capitalNecesario: IImporte;

}
