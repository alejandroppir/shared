/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: cag.bg.segurospaso.vendors.vidamodular
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133990595815366942
    Date: 07/08/2025
    Time: 18:59
*/
import { IJsonApiObject } from '@morphe/common';
import { IJsonApiData } from '@morphe/common';
import { IJsonApiCollection } from '@morphe/common';
import { ISituacionActualDelEstudioResponseAttributes
       } from './SituacionActualDelEstudioResponseAttributes';

export interface ISituacionActualDelEstudioResponse
       extends IJsonApiObject<ISituacionActualDelEstudioResponseAttributes> {
}

export interface ISituacionActualDelEstudioResponseCollection
       extends IJsonApiCollection<ISituacionActualDelEstudioResponseAttributes> {
}
