/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: cag.bg.segurospaso.vendors.vidamodular
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133990595815366942
    Date: 07/08/2025
    Time: 18:59
*/

export interface ILocal {

  // tipoDeVia 
  tipoDeVia: string;
  // nombreDeVia 
  nombreDeVia: string;
  // numeroDeVia 
  numeroDeVia: number;
  // codigoPostal 
  codigoPostal: number;
  // poblacion 
  poblacion: string;
  // provincia 
  provincia: string;
  // anhoDeConstruccion 
  anhoDeConstruccion: number;
  // anhoDeLaUltimaReforma 
  anhoDeLaUltimaReforma: number;
  // superficie 
  superficie: number;
  // altura 
  altura: string;

}
