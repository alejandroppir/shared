/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: cag.bg.segurospaso.vendors.vidamodular
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133990595815366942
    Date: 07/08/2025
    Time: 18:59
*/
export enum Schema {
    Capital =
      'capital',
    CapitalPostRequest =
      'capitalPostRequest',
    CapitalPostRequestAttributes =
      'capitalPostRequestAttributes',
    CapitalPostRequestData =
      'capitalPostRequestData',
    CapitalResponse =
      'capitalResponse',
    CapitalResponseAttributes =
      'capitalResponseAttributes',
    CapitalResponseCollection =
      'capitalResponseCollection',
    CapitalResponseData =
      'capitalResponseData',
    CoberturaAttributes =
      'coberturaAttributes',
    DocumentoIdentificativo =
      'documentoIdentificativo',
    ErrorObject =
      'errorObject',
    ErrorsObject =
      'errorsObject',
    HorariosDeReconocimientosMedicoRequest =
      'horariosDeReconocimientosMedicoRequest',
    HorariosDeReconocimientosMedicoRequestAttributes =
      'horariosDeReconocimientosMedicoRequestAttributes',
    HorariosDeReconocimientosMedicoRequestData =
      'horariosDeReconocimientosMedicoRequestData',
    Importe =
      'importe',
    ImporteDeValor =
      'importeDeValor',
    ImporteDeValorSinFixing =
      'importeDeValorSinFixing',
    LinkCollectionObject =
      'linkCollectionObject',
    LinkErrorObject =
      'linkErrorObject',
    LinkResourceObject =
      'linkResourceObject',
    Local =
      'local',
    ProgresionEconomicaResponse =
      'progresionEconomicaResponse',
    ProgresionEconomicaResponseAttributes =
      'progresionEconomicaResponseAttributes',
    ProgresionEconomicaResponseCollection =
      'progresionEconomicaResponseCollection',
    ProgresionEconomicaResponseData =
      'progresionEconomicaResponseData',
    SimulacionRequest =
      'simulacionRequest',
    SimulacionRequestAttributes =
      'simulacionRequestAttributes',
    SimulacionRequestData =
      'simulacionRequestData',
    SimulacionResponse =
      'simulacionResponse',
    SimulacionResponseAttributes =
      'simulacionResponseAttributes',
    SimulacionResponseData =
      'simulacionResponseData',
    SituacionActualDelEstudioResponse =
      'situacionActualDelEstudioResponse',
    SituacionActualDelEstudioResponseAttributes =
      'situacionActualDelEstudioResponseAttributes',
    SituacionActualDelEstudioResponseCollection =
      'situacionActualDelEstudioResponseCollection',
    SituacionActualDelEstudioResponseData =
      'situacionActualDelEstudioResponseData',
    SociedadResponse =
      'sociedadResponse',
    SociedadResponseAttributes =
      'sociedadResponseAttributes',
    SociedadResponseCollection =
      'sociedadResponseCollection',
    SociedadResponseData =
      'sociedadResponseData',
    Source =
      'source',
    TipoDeDeporteResponse =
      'tipoDeDeporteResponse',
    TipoDeDeporteResponseAttributes =
      'tipoDeDeporteResponseAttributes',
    TipoDeDeporteResponseCollection =
      'tipoDeDeporteResponseCollection',
    TipoDeDeporteResponseData =
      'tipoDeDeporteResponseData',
    TipoDeProfesionResponse =
      'tipoDeProfesionResponse',
    TipoDeProfesionResponseAttributes =
      'tipoDeProfesionResponseAttributes',
    TipoDeProfesionResponseCollection =
      'tipoDeProfesionResponseCollection',
    TipoDeProfesionResponseData =
      'tipoDeProfesionResponseData'
}
