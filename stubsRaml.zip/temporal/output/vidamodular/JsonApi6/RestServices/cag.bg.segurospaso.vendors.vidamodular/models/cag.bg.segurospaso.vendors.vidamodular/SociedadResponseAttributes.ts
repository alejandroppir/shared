/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: cag.bg.segurospaso.vendors.vidamodular
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133990595815366942
    Date: 07/08/2025
    Time: 18:59
*/
import { IImporte } from './Importe';
import { ILocal } from './Local';

export interface ISociedadResponseAttributes {

  // nif 
  nif: string;
  // denominacionSocial 
  denominacionSocial: string;
  // nombreComercial 
  nombreComercial: string;
  // codigoDeEstado 
  codigoDeEstado: string;
  // fechaDeConstitucion 
  fechaDeConstitucion: Date;
  // codigoDeCNAE 
  codigoDeCNAE: string;
  // descripcionDeCNAE 
  descripcionDeCNAE: string;
  // facturacionAnual 
  facturacionAnual: IImporte;
  // numeroDeEmpleados 
  numeroDeEmpleados: number;
  // local 
  local: ILocal;

}
