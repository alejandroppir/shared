import { Observable } from 'rxjs';
import { IJsonApiData } from '@morphe/common';
/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: cag.bg.segurospaso.vendors.vidamodular
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133990595815366942
    Date: 07/08/2025
    Time: 18:59
*/
// Imports de modelos
import { IProgresionEconomicaResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/progresionEconomicaResponseAttributes';
import { ISituacionActualDelEstudioResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/situacionActualDelEstudioResponseAttributes';
import { ITipoDeDeporteResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/tipoDeDeporteResponseAttributes';
import { ITipoDeProfesionResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/tipoDeProfesionResponseAttributes';
import { ISimulacionRequestAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/simulacionRequestAttributes';
import { IHorariosDeReconocimientosMedicoRequestAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/horariosDeReconocimientosMedicoRequestAttributes';
import { ICapitalPostRequestAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/capitalPostRequestAttributes';


// Interface
export interface ISegurosService {
  // GET for 'seguros/paso/vidaModular/progresionesEconomicas'
  
  getProgresionEconomicaResponse (identificadorDeOportunidad? : number  ) : Observable<IJsonApiData<IProgresionEconomicaResponseAttributes>[]>;
  // GET for 'seguros/paso/vidaModular/situacionActualDelEstudio'
  
  
  getSituacionActualDelEstudioResponse (identificadorDeOportunidad? : number  ) : Observable<ISituacionActualDelEstudioResponseAttributes>;
  // GET for 'seguros/paso/vidaModular/tiposDeDeportes'
  
  getTipoDeDeporteResponse (versionHeredada? : boolean  ) : Observable<IJsonApiData<ITipoDeDeporteResponseAttributes>[]>;
  // GET for 'seguros/paso/vidaModular/tiposDeDeportes/{tipoDeDeporteId}'
  
  
  getTipoDeDeporteResponse (tipoDeDeporteId? : string  ) : Observable<ITipoDeDeporteResponseAttributes>;
  // GET for 'seguros/paso/vidaModular/tiposDeProfesiones'
  
  getTipoDeProfesionResponse (versionHeredada? : boolean  ) : Observable<IJsonApiData<ITipoDeProfesionResponseAttributes>[]>;
  // GET for 'seguros/paso/vidaModular/tiposDeProfesiones/{tipoDeProfesionId}'
  
  
  getTipoDeProfesionResponse (tipoDeProfesionId? : string  ) : Observable<ITipoDeProfesionResponseAttributes>;
  // IPOSTMSC seguros/paso/vidaModular/simulaciones
  // IPOSTONEWAY seguros/paso/vidaModular/simulaciones
  addSimulacionRequest(simulacionRequest : ISimulacionRequestAttributes  ): Observable<any>;
  // IPOSTONEWAY seguros/paso/vidaModular/horariosDeReconocimientosMedico
  addHorariosDeReconocimientosMedicoRequest(horariosDeReconocimientosMedicoRequest : IHorariosDeReconocimientosMedicoRequestAttributes  ): Observable<any>;
  // IPOSTONEWAY seguros/paso/vidaModular/capitales
  addCapitalPostRequest(capitalPostRequest : ICapitalPostRequestAttributes  ): Observable<any>;
}
