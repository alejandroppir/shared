import { Observable } from 'rxjs';
import { IJsonApiData } from '@morphe/common';
/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: cag.bg.segurospaso.vendors.vidamodular
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133990595815366942
    Date: 07/08/2025
    Time: 18:59
*/
// Imports de modelos
import { IProgresionEconomicaResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/progresionEconomicaResponseAttributes';
import { ISituacionActualDelEstudioResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/situacionActualDelEstudioResponseAttributes';
import { ITipoDeDeporteResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/tipoDeDeporteResponseAttributes';
import { ITipoDeProfesionResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/tipoDeProfesionResponseAttributes';
import { ISimulacionRequestAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/simulacionRequestAttributes';
import { IHorariosDeReconocimientosMedicoRequestAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/horariosDeReconocimientosMedicoRequestAttributes';


// Interface
export interface IMeService {
  // GET for 'me/seguros/paso/vidaModular/progresionesEconomicas'
  
  getProgresionEconomicaResponse (identificadorDeOportunidad? : string  ) : Observable<IJsonApiData<IProgresionEconomicaResponseAttributes>[]>;
  // GET for 'me/seguros/paso/vidaModular/situacionActualDelEstudio'
  
  
  getSituacionActualDelEstudioResponse (identificadorDeOportunidad? : number  ) : Observable<ISituacionActualDelEstudioResponseAttributes>;
  // GET for 'me/seguros/paso/vidaModular/tiposDeDeportes'
  
  getTipoDeDeporteResponse (versionHeredada? : boolean  ) : Observable<IJsonApiData<ITipoDeDeporteResponseAttributes>[]>;
  // GET for 'me/seguros/paso/vidaModular/tiposDeDeportes/{tipoDeDeporteId}'
  
  
  getTipoDeDeporteResponse (tipoDeDeporteId? : string  ) : Observable<ITipoDeDeporteResponseAttributes>;
  // GET for 'me/seguros/paso/vidaModular/tiposDeProfesiones'
  
  getTipoDeProfesionResponse (versionHeredada? : boolean  ) : Observable<IJsonApiData<ITipoDeProfesionResponseAttributes>[]>;
  // GET for 'me/seguros/paso/vidaModular/tiposDeProfesiones/{tipoDeProfesionId}'
  
  
  getTipoDeProfesionResponse (tipoDeProfesionId? : string  ) : Observable<ITipoDeProfesionResponseAttributes>;
  // IPOSTMSC me/seguros/paso/vidaModular/simulaciones
  // IPOSTONEWAY me/seguros/paso/vidaModular/simulaciones
  addSimulacionRequest(simulacionRequest : ISimulacionRequestAttributes  ): Observable<any>;
  // IPOSTONEWAY me/seguros/paso/vidaModular/horariosDeReconocimientosMedico
  addHorariosDeReconocimientosMedicoRequest(horariosDeReconocimientosMedicoRequest : IHorariosDeReconocimientosMedicoRequestAttributes  ): Observable<any>;
}
