/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: cag.bg.segurospaso.vendors.vidamodular
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133990595815366942
    Date: 07/08/2025
    Time: 18:59
*/
import { Injectable } from '@angular/core';
import { BasicHttpClientService } from '@morphe/api';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { IJsonApiObject } from '@morphe/common';
import { IJsonApiData } from '@morphe/common';
import { IJsonApiCollection } from '@morphe/common';
import { JsonApiHelper } from '@morphe/common';
import { ISegurosService } from './ISegurosService';
// Imports de modelos
import { IProgresionEconomicaResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/progresionEconomicaResponseAttributes';
import { ISituacionActualDelEstudioResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/situacionActualDelEstudioResponseAttributes';
import { ITipoDeDeporteResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/tipoDeDeporteResponseAttributes';
import { ITipoDeProfesionResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/tipoDeProfesionResponseAttributes';
import { ISimulacionRequestAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/simulacionRequestAttributes';
import { ISimulacionResponseAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/simulacionResponseAttributes';
import { IHorariosDeReconocimientosMedicoRequestAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/horariosDeReconocimientosMedicoRequestAttributes';
import { IAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/Attributes';
import { ICapitalPostRequestAttributes } from '../../models/cag.bg.segurospaso.vendors.vidamodular/capitalPostRequestAttributes';


// Class
@Injectable()
export class SegurosService implements ISegurosService {
  
  constructor(private http: BasicHttpClientService) {
  }

  private getCGDNCode(): string {
    return 'AAAANNN';
  }

  
  
  // GET for 'seguros/paso/vidaModular/progresionesEconomicas'
  
  getProgresionEconomicaResponse ( {} ) : Observable<IJsonApiData<IProgresionEconomicaResponseAttributes>[]>;
  getProgresionEconomicaResponse (identificadorDeOportunidad? : number  ) : Observable<IJsonApiData<IProgresionEconomicaResponseAttributes>[]>{
      const url = `seguros/paso/vidaModular/progresionesEconomicas`;
      var params;
      if (typeof arguments[0]=="object" && arguments.length==1) {
        params=arguments[0];
      }
      else{
        params = new Object();
        params.identificadorDeOportunidad = arguments[0];
        
      }
      return this.http.apiGet<IJsonApiCollection<IProgresionEconomicaResponseAttributes>>(this.getCGDNCode(), url, params).pipe(
          map(respuesta => respuesta.body.data)
      );
  }
  
  
  // GET for 'seguros/paso/vidaModular/situacionActualDelEstudio'
  
  
  getSituacionActualDelEstudioResponse ( {} ) : Observable<ISituacionActualDelEstudioResponseAttributes>;
  getSituacionActualDelEstudioResponse (identificadorDeOportunidad? : number  ) : Observable<ISituacionActualDelEstudioResponseAttributes> {
      const url = `seguros/paso/vidaModular/situacionActualDelEstudio`;
      var params;
      if (typeof arguments[0]=="object" && arguments.length==1) {
        params=arguments[0];
      }
      else{
        params = new Object();
        params.identificadorDeOportunidad = arguments[0];
        
      }
  
      return this.http.apiGet<IJsonApiObject<ISituacionActualDelEstudioResponseAttributes>>(this.getCGDNCode(), url, params).pipe(
        map(respuesta => respuesta.body.data.attributes)
      );
  }
  
  
  // GET for 'seguros/paso/vidaModular/tiposDeDeportes'
  
  getTipoDeDeporteResponse ( {} ) : Observable<IJsonApiData<ITipoDeDeporteResponseAttributes>[]>;
  getTipoDeDeporteResponse (versionHeredada? : boolean  ) : Observable<IJsonApiData<ITipoDeDeporteResponseAttributes>[]>{
      const url = `seguros/paso/vidaModular/tiposDeDeportes`;
      var params;
      if (typeof arguments[0]=="object" && arguments.length==1) {
        params=arguments[0];
      }
      else{
        params = new Object();
        params.versionHeredada = arguments[0];
        
      }
      return this.http.apiGet<IJsonApiCollection<ITipoDeDeporteResponseAttributes>>(this.getCGDNCode(), url, params).pipe(
          map(respuesta => respuesta.body.data)
      );
  }
  
  
  // GET for 'seguros/paso/vidaModular/tiposDeDeportes/{tipoDeDeporteId}'
  
  
  getTipoDeDeporteResponse ( {} ) : Observable<ITipoDeDeporteResponseAttributes>;
  getTipoDeDeporteResponse (tipoDeDeporteId? : string  ) : Observable<ITipoDeDeporteResponseAttributes> {
      const url = `seguros/paso/vidaModular/tiposDeDeportes/${tipoDeDeporteId}`;
      var params;
      if (typeof arguments[0]=="object" && arguments.length==1) {
        params=arguments[0];
      }
      else{
        params = new Object();
        
      }
  
      return this.http.apiGet<IJsonApiObject<ITipoDeDeporteResponseAttributes>>(this.getCGDNCode(), url, params).pipe(
        map(respuesta => respuesta.body.data.attributes)
      );
  }
  
  
  // GET for 'seguros/paso/vidaModular/tiposDeProfesiones'
  
  getTipoDeProfesionResponse ( {} ) : Observable<IJsonApiData<ITipoDeProfesionResponseAttributes>[]>;
  getTipoDeProfesionResponse (versionHeredada? : boolean  ) : Observable<IJsonApiData<ITipoDeProfesionResponseAttributes>[]>{
      const url = `seguros/paso/vidaModular/tiposDeProfesiones`;
      var params;
      if (typeof arguments[0]=="object" && arguments.length==1) {
        params=arguments[0];
      }
      else{
        params = new Object();
        params.versionHeredada = arguments[0];
        
      }
      return this.http.apiGet<IJsonApiCollection<ITipoDeProfesionResponseAttributes>>(this.getCGDNCode(), url, params).pipe(
          map(respuesta => respuesta.body.data)
      );
  }
  
  
  // GET for 'seguros/paso/vidaModular/tiposDeProfesiones/{tipoDeProfesionId}'
  
  
  getTipoDeProfesionResponse ( {} ) : Observable<ITipoDeProfesionResponseAttributes>;
  getTipoDeProfesionResponse (tipoDeProfesionId? : string  ) : Observable<ITipoDeProfesionResponseAttributes> {
      const url = `seguros/paso/vidaModular/tiposDeProfesiones/${tipoDeProfesionId}`;
      var params;
      if (typeof arguments[0]=="object" && arguments.length==1) {
        params=arguments[0];
      }
      else{
        params = new Object();
        
      }
  
      return this.http.apiGet<IJsonApiObject<ITipoDeProfesionResponseAttributes>>(this.getCGDNCode(), url, params).pipe(
        map(respuesta => respuesta.body.data.attributes)
      );
  }
  // POSTMSC seguros/paso/vidaModular/simulaciones
  // POST ONE WAY seguros/paso/vidaModular/simulaciones
  addSimulacionRequest(simulacionRequest : ISimulacionRequestAttributes  ): Observable<any> {
    const url = `seguros/paso/vidaModular/simulaciones`;
  
    const data: IJsonApiData<ISimulacionRequestAttributes> = JsonApiHelper.createJsonApiData();
    data.attributes = simulacionRequest;
    const body: IJsonApiObject<any> = JsonApiHelper.createJsonApiObject();
    body.data = data;
  
    return this.http.apiPost<IJsonApiObject<any>>(this.getCGDNCode(), url, body ).pipe(
          map(response => { return response; })
    );
  }
  // POST ONE WAY seguros/paso/vidaModular/horariosDeReconocimientosMedico
  addHorariosDeReconocimientosMedicoRequest(horariosDeReconocimientosMedicoRequest : IHorariosDeReconocimientosMedicoRequestAttributes  ): Observable<any> {
    const url = `seguros/paso/vidaModular/horariosDeReconocimientosMedico`;
  
    const data: IJsonApiData<IHorariosDeReconocimientosMedicoRequestAttributes> = JsonApiHelper.createJsonApiData();
    data.attributes = horariosDeReconocimientosMedicoRequest;
    const body: IJsonApiObject<any> = JsonApiHelper.createJsonApiObject();
    body.data = data;
  
    return this.http.apiPost<IJsonApiObject<any>>(this.getCGDNCode(), url, body ).pipe(
          map(response => { return response; })
    );
  }
  // POST ONE WAY seguros/paso/vidaModular/capitales
  addCapitalPostRequest(capitalPostRequest : ICapitalPostRequestAttributes  ): Observable<any> {
    const url = `seguros/paso/vidaModular/capitales`;
  
    const data: IJsonApiData<ICapitalPostRequestAttributes> = JsonApiHelper.createJsonApiData();
    data.attributes = capitalPostRequest;
    const body: IJsonApiObject<any> = JsonApiHelper.createJsonApiObject();
    body.data = data;
  
    return this.http.apiPost<IJsonApiObject<any>>(this.getCGDNCode(), url, body ).pipe(
          map(response => { return response; })
    );
  }

}
