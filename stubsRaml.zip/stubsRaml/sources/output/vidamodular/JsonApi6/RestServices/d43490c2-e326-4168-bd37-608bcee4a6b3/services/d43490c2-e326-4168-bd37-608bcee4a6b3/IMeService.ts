import { Observable } from 'rxjs';
import { IJsonApiData } from '@morphe/common';
/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: d43490c2-e326-4168-bd37-608bcee4a6b3
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133991081461895358
    Date: 08-08-2025
    Time: 8:29
*/
// Imports de modelos
import { IProgresionEconomicaResponseAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/progresionEconomicaResponseAttributes';
import { ISituacionActualDelEstudioResponseAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/situacionActualDelEstudioResponseAttributes';
import { ITipoDeDeporteResponseAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/tipoDeDeporteResponseAttributes';
import { ITipoDeProfesionResponseAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/tipoDeProfesionResponseAttributes';
import { ISimulacionRequestAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/simulacionRequestAttributes';
import { IHorariosDeReconocimientosMedicoRequestAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/horariosDeReconocimientosMedicoRequestAttributes';


// Interface
export interface IMeService {
  // GET for 'me/seguros/paso/vidaModular/progresionesEconomicas'
  
  getProgresionEconomicaResponse (identificadorDeOportunidad? : string  ) : Observable<IJsonApiData<IProgresionEconomicaResponseAttributes>[]>;
  // GET for 'me/seguros/paso/vidaModular/situacionActualDelEstudio'
  
  
  getSituacionActualDelEstudioResponse (identificadorDeOportunidad? : number  ) : Observable<ISituacionActualDelEstudioResponseAttributes>;
  // GET for 'me/seguros/paso/vidaModular/tiposDeDeportes'
  
  getTipoDeDeporteResponse (versionHeredada? : boolean  ) : Observable<IJsonApiData<ITipoDeDeporteResponseAttributes>[]>;
  // GET for 'me/seguros/paso/vidaModular/tiposDeDeportes/{tipoDeDeporteId}'
  
  
  getTipoDeDeporteResponse (tipoDeDeporteId? : string  ) : Observable<ITipoDeDeporteResponseAttributes>;
  // GET for 'me/seguros/paso/vidaModular/tiposDeProfesiones'
  
  getTipoDeProfesionResponse (versionHeredada? : boolean  ) : Observable<IJsonApiData<ITipoDeProfesionResponseAttributes>[]>;
  // GET for 'me/seguros/paso/vidaModular/tiposDeProfesiones/{tipoDeProfesionId}'
  
  
  getTipoDeProfesionResponse (tipoDeProfesionId? : string  ) : Observable<ITipoDeProfesionResponseAttributes>;
  // IPOSTMSC me/seguros/paso/vidaModular/simulaciones
  // IPOSTONEWAY me/seguros/paso/vidaModular/simulaciones
  addSimulacionRequest(simulacionRequest : ISimulacionRequestAttributes  ): Observable<any>;
  // IPOSTONEWAY me/seguros/paso/vidaModular/horariosDeReconocimientosMedico
  addHorariosDeReconocimientosMedicoRequest(horariosDeReconocimientosMedicoRequest : IHorariosDeReconocimientosMedicoRequestAttributes  ): Observable<any>;
}
