/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: d43490c2-e326-4168-bd37-608bcee4a6b3
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133991081461895358
    Date: 08-08-2025
    Time: 8:29
*/
import { Injectable } from '@angular/core';
import { BasicHttpClientService } from '@morphe/api';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { IJsonApiObject } from '@morphe/common';
import { IJsonApiData } from '@morphe/common';
import { IJsonApiCollection } from '@morphe/common';
import { JsonApiHelper } from '@morphe/common';
import { IMeService } from './IMeService';
// Imports de modelos
import { IProgresionEconomicaResponseAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/progresionEconomicaResponseAttributes';
import { ISituacionActualDelEstudioResponseAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/situacionActualDelEstudioResponseAttributes';
import { ITipoDeDeporteResponseAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/tipoDeDeporteResponseAttributes';
import { ITipoDeProfesionResponseAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/tipoDeProfesionResponseAttributes';
import { ISimulacionRequestAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/simulacionRequestAttributes';
import { ISimulacionResponseAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/simulacionResponseAttributes';
import { IHorariosDeReconocimientosMedicoRequestAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/horariosDeReconocimientosMedicoRequestAttributes';
import { IAttributes } from '../../models/d43490c2-e326-4168-bd37-608bcee4a6b3/Attributes';


// Class
@Injectable()
export class MeService implements IMeService {
  
  constructor(private http: BasicHttpClientService) {
  }

  private getCGDNCode(): string {
    return 'AAAANNN';
  }

  
  
  // GET for 'me/seguros/paso/vidaModular/progresionesEconomicas'
  
  getProgresionEconomicaResponse ( {} ) : Observable<IJsonApiData<IProgresionEconomicaResponseAttributes>[]>;
  getProgresionEconomicaResponse (identificadorDeOportunidad? : string  ) : Observable<IJsonApiData<IProgresionEconomicaResponseAttributes>[]>{
      const url = `me/seguros/paso/vidaModular/progresionesEconomicas`;
      var params;
      if (typeof arguments[0]=="object" && arguments.length==1) {
        params=arguments[0];
      }
      else{
        params = new Object();
        params.identificadorDeOportunidad = arguments[0];
        
      }
      return this.http.apiGet<IJsonApiCollection<IProgresionEconomicaResponseAttributes>>(this.getCGDNCode(), url, params).pipe(
          map(respuesta => respuesta.body.data)
      );
  }
  
  
  // GET for 'me/seguros/paso/vidaModular/situacionActualDelEstudio'
  
  
  getSituacionActualDelEstudioResponse ( {} ) : Observable<ISituacionActualDelEstudioResponseAttributes>;
  getSituacionActualDelEstudioResponse (identificadorDeOportunidad? : number  ) : Observable<ISituacionActualDelEstudioResponseAttributes> {
      const url = `me/seguros/paso/vidaModular/situacionActualDelEstudio`;
      var params;
      if (typeof arguments[0]=="object" && arguments.length==1) {
        params=arguments[0];
      }
      else{
        params = new Object();
        params.identificadorDeOportunidad = arguments[0];
        
      }
  
      return this.http.apiGet<IJsonApiObject<ISituacionActualDelEstudioResponseAttributes>>(this.getCGDNCode(), url, params).pipe(
        map(respuesta => respuesta.body.data.attributes)
      );
  }
  
  
  // GET for 'me/seguros/paso/vidaModular/tiposDeDeportes'
  
  getTipoDeDeporteResponse ( {} ) : Observable<IJsonApiData<ITipoDeDeporteResponseAttributes>[]>;
  getTipoDeDeporteResponse (versionHeredada? : boolean  ) : Observable<IJsonApiData<ITipoDeDeporteResponseAttributes>[]>{
      const url = `me/seguros/paso/vidaModular/tiposDeDeportes`;
      var params;
      if (typeof arguments[0]=="object" && arguments.length==1) {
        params=arguments[0];
      }
      else{
        params = new Object();
        params.versionHeredada = arguments[0];
        
      }
      return this.http.apiGet<IJsonApiCollection<ITipoDeDeporteResponseAttributes>>(this.getCGDNCode(), url, params).pipe(
          map(respuesta => respuesta.body.data)
      );
  }
  
  
  // GET for 'me/seguros/paso/vidaModular/tiposDeDeportes/{tipoDeDeporteId}'
  
  
  getTipoDeDeporteResponse ( {} ) : Observable<ITipoDeDeporteResponseAttributes>;
  getTipoDeDeporteResponse (tipoDeDeporteId? : string  ) : Observable<ITipoDeDeporteResponseAttributes> {
      const url = `me/seguros/paso/vidaModular/tiposDeDeportes/${tipoDeDeporteId}`;
      var params;
      if (typeof arguments[0]=="object" && arguments.length==1) {
        params=arguments[0];
      }
      else{
        params = new Object();
        
      }
  
      return this.http.apiGet<IJsonApiObject<ITipoDeDeporteResponseAttributes>>(this.getCGDNCode(), url, params).pipe(
        map(respuesta => respuesta.body.data.attributes)
      );
  }
  
  
  // GET for 'me/seguros/paso/vidaModular/tiposDeProfesiones'
  
  getTipoDeProfesionResponse ( {} ) : Observable<IJsonApiData<ITipoDeProfesionResponseAttributes>[]>;
  getTipoDeProfesionResponse (versionHeredada? : boolean  ) : Observable<IJsonApiData<ITipoDeProfesionResponseAttributes>[]>{
      const url = `me/seguros/paso/vidaModular/tiposDeProfesiones`;
      var params;
      if (typeof arguments[0]=="object" && arguments.length==1) {
        params=arguments[0];
      }
      else{
        params = new Object();
        params.versionHeredada = arguments[0];
        
      }
      return this.http.apiGet<IJsonApiCollection<ITipoDeProfesionResponseAttributes>>(this.getCGDNCode(), url, params).pipe(
          map(respuesta => respuesta.body.data)
      );
  }
  
  
  // GET for 'me/seguros/paso/vidaModular/tiposDeProfesiones/{tipoDeProfesionId}'
  
  
  getTipoDeProfesionResponse ( {} ) : Observable<ITipoDeProfesionResponseAttributes>;
  getTipoDeProfesionResponse (tipoDeProfesionId? : string  ) : Observable<ITipoDeProfesionResponseAttributes> {
      const url = `me/seguros/paso/vidaModular/tiposDeProfesiones/${tipoDeProfesionId}`;
      var params;
      if (typeof arguments[0]=="object" && arguments.length==1) {
        params=arguments[0];
      }
      else{
        params = new Object();
        
      }
  
      return this.http.apiGet<IJsonApiObject<ITipoDeProfesionResponseAttributes>>(this.getCGDNCode(), url, params).pipe(
        map(respuesta => respuesta.body.data.attributes)
      );
  }
  // POSTMSC me/seguros/paso/vidaModular/simulaciones
  // POST ONE WAY me/seguros/paso/vidaModular/simulaciones
  addSimulacionRequest(simulacionRequest : ISimulacionRequestAttributes  ): Observable<any> {
    const url = `me/seguros/paso/vidaModular/simulaciones`;
  
    const data: IJsonApiData<ISimulacionRequestAttributes> = JsonApiHelper.createJsonApiData();
    data.attributes = simulacionRequest;
    const body: IJsonApiObject<any> = JsonApiHelper.createJsonApiObject();
    body.data = data;
  
    return this.http.apiPost<IJsonApiObject<any>>(this.getCGDNCode(), url, body ).pipe(
          map(response => { return response; })
    );
  }
  // POST ONE WAY me/seguros/paso/vidaModular/horariosDeReconocimientosMedico
  addHorariosDeReconocimientosMedicoRequest(horariosDeReconocimientosMedicoRequest : IHorariosDeReconocimientosMedicoRequestAttributes  ): Observable<any> {
    const url = `me/seguros/paso/vidaModular/horariosDeReconocimientosMedico`;
  
    const data: IJsonApiData<IHorariosDeReconocimientosMedicoRequestAttributes> = JsonApiHelper.createJsonApiData();
    data.attributes = horariosDeReconocimientosMedicoRequest;
    const body: IJsonApiObject<any> = JsonApiHelper.createJsonApiObject();
    body.data = data;
  
    return this.http.apiPost<IJsonApiObject<any>>(this.getCGDNCode(), url, body ).pipe(
          map(response => { return response; })
    );
  }

}
