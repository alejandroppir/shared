/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: d43490c2-e326-4168-bd37-608bcee4a6b3
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133991081461895358
    Date: 08-08-2025
    Time: 8:29
*/

export interface ISimulacionResponseAttributes {

  // primaTarTotal 
  primaTarTotal: number;
  // primaTarAnho1 
  primaTarAnho1: number;
  // primaTarAnho2 
  primaTarAnho2: number;
  // primaTarAnho3 
  primaTarAnho3: number;
  // primaTarAnho4 
  primaTarAnho4: number;
  // primaTarAnho5 
  primaTarAnho5: number;
  // primaPu 
  primaPu: number;

}
