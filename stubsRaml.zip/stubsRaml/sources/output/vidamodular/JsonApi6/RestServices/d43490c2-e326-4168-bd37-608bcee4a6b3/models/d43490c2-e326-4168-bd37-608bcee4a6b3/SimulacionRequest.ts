/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: d43490c2-e326-4168-bd37-608bcee4a6b3
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133991081461895358
    Date: 08-08-2025
    Time: 8:29
*/
import { IJsonApiObject } from '@morphe/common';
import { IJsonApiData } from '@morphe/common';
import { IJsonApiCollection } from '@morphe/common';
import { ISimulacionRequestAttributes
       } from './SimulacionRequestAttributes';

export interface ISimulacionRequest
       extends IJsonApiObject<ISimulacionRequestAttributes> {
}

export interface ISimulacionRequestCollection
       extends IJsonApiCollection<ISimulacionRequestAttributes> {
}
