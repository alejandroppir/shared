/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: d43490c2-e326-4168-bd37-608bcee4a6b3
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133991081461895358
    Date: 08-08-2025
    Time: 8:29
*/
export enum Schema {
    Capital =
      'capital',
    CapitalPostRequest =
      'capitalPostRequest',
    CapitalPostRequestAttributes =
      'capitalPostRequestAttributes',
    CapitalPostRequestData =
      'capitalPostRequestData',
    CapitalResponse =
      'capitalResponse',
    CapitalResponseAttributes =
      'capitalResponseAttributes',
    CapitalResponseCollection =
      'capitalResponseCollection',
    CapitalResponseData =
      'capitalResponseData',
    CoberturaAttributes =
      'coberturaAttributes',
    DocumentoIdentificativo =
      'documentoIdentificativo',
    ErrorObject =
      'errorObject',
    ErrorsObject =
      'errorsObject',
    HorariosDeReconocimientosMedicoRequest =
      'horariosDeReconocimientosMedicoRequest',
    HorariosDeReconocimientosMedicoRequestAttributes =
      'horariosDeReconocimientosMedicoRequestAttributes',
    HorariosDeReconocimientosMedicoRequestData =
      'horariosDeReconocimientosMedicoRequestData',
    Importe =
      'importe',
    ImporteDeValor =
      'importeDeValor',
    ImporteDeValorSinFixing =
      'importeDeValorSinFixing',
    LinkCollectionObject =
      'linkCollectionObject',
    LinkErrorObject =
      'linkErrorObject',
    LinkResourceObject =
      'linkResourceObject',
    Local =
      'local',
    ProgresionEconomicaResponse =
      'progresionEconomicaResponse',
    ProgresionEconomicaResponseAttributes =
      'progresionEconomicaResponseAttributes',
    ProgresionEconomicaResponseCollection =
      'progresionEconomicaResponseCollection',
    ProgresionEconomicaResponseData =
      'progresionEconomicaResponseData',
    SimulacionRequest =
      'simulacionRequest',
    SimulacionRequestAttributes =
      'simulacionRequestAttributes',
    SimulacionRequestData =
      'simulacionRequestData',
    SimulacionResponse =
      'simulacionResponse',
    SimulacionResponseAttributes =
      'simulacionResponseAttributes',
    SimulacionResponseData =
      'simulacionResponseData',
    SituacionActualDelEstudioResponse =
      'situacionActualDelEstudioResponse',
    SituacionActualDelEstudioResponseAttributes =
      'situacionActualDelEstudioResponseAttributes',
    SituacionActualDelEstudioResponseCollection =
      'situacionActualDelEstudioResponseCollection',
    SituacionActualDelEstudioResponseData =
      'situacionActualDelEstudioResponseData',
    SociedadResponse =
      'sociedadResponse',
    SociedadResponseAttributes =
      'sociedadResponseAttributes',
    SociedadResponseCollection =
      'sociedadResponseCollection',
    SociedadResponseData =
      'sociedadResponseData',
    Source =
      'source',
    TipoDeDeporteResponse =
      'tipoDeDeporteResponse',
    TipoDeDeporteResponseAttributes =
      'tipoDeDeporteResponseAttributes',
    TipoDeDeporteResponseCollection =
      'tipoDeDeporteResponseCollection',
    TipoDeDeporteResponseData =
      'tipoDeDeporteResponseData',
    TipoDeProfesionResponse =
      'tipoDeProfesionResponse',
    TipoDeProfesionResponseAttributes =
      'tipoDeProfesionResponseAttributes',
    TipoDeProfesionResponseCollection =
      'tipoDeProfesionResponseCollection',
    TipoDeProfesionResponseData =
      'tipoDeProfesionResponseData'
}
