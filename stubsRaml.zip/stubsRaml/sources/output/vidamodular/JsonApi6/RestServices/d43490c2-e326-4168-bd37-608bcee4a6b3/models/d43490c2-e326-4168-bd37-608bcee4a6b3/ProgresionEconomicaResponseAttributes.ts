/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: d43490c2-e326-4168-bd37-608bcee4a6b3
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133991081461895358
    Date: 08-08-2025
    Time: 8:29
*/
import { IImporte } from './Importe';

export interface IProgresionEconomicaResponseAttributes {

  // identificadorDeOportunidad 
  identificadorDeOportunidad: number;
  // anho 
  anho: number;
  // ingresosConyuge 
  ingresosConyuge: IImporte;
  // ingresosViudedad 
  ingresosViudedad: IImporte;
  // ingresosOrfandad 
  ingresosOrfandad: IImporte;
  // ingresosOrfandadComplemento 
  ingresosOrfandadComplemento: IImporte;
  // ingresosInvalidez 
  ingresosInvalidez: IImporte;
  // ingresosActuales 
  ingresosActuales: IImporte;
  // perdidaDeIngresos 
  perdidaDeIngresos: IImporte;
  // capitalNecesario 
  capitalNecesario: IImporte;

}
