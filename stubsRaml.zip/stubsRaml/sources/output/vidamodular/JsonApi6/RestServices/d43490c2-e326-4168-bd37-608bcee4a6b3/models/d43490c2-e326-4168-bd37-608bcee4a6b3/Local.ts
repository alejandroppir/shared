/*
  Created with caraml API Editor 3.0

  Context Info:
    SourceDocName: d43490c2-e326-4168-bd37-608bcee4a6b3
    RAMLDescription: API para la gestión de particularidades de los seguros para vida modular dentro de la plataforma PASO (Plataforma Abanca Seguros Omnicanal)
    RAMLDocVersion: v1
    TimeStamp: 133991081461895358
    Date: 08-08-2025
    Time: 8:29
*/

export interface ILocal {

  // tipoDeVia 
  tipoDeVia: string;
  // nombreDeVia 
  nombreDeVia: string;
  // numeroDeVia 
  numeroDeVia: number;
  // codigoPostal 
  codigoPostal: number;
  // poblacion 
  poblacion: string;
  // provincia 
  provincia: string;
  // anhoDeConstruccion 
  anhoDeConstruccion: number;
  // anhoDeLaUltimaReforma 
  anhoDeLaUltimaReforma: number;
  // superficie 
  superficie: number;
  // altura 
  altura: string;

}
