# Emisión de texto y pulsaciones desde macros

Este documento explica cómo definir acciones en `keyboard.js` y qué formatos puedes usar para que el exe `.\MacroHotKey\bin\Release\...\MacroHotKey.exe` emita texto o pulsaciones de tecla.

## Resumen

- La configuración está en `config.jsonc` en la raíz del proyecto. El archivo debe contener `listenerMods` y `macroMap`.
- El puente JS (`keyboard.js`) recibe la tecla (A-Z) desde el exe y ejecuta la acción definida en `macroMap`.
- Para ejecutar la acción, `keyboard.js` llama al exe con `emit` y un argumento. El exe usa `SendKeys.SendWait(...)` para ejecutar la secuencia.
- Para ejecutar la acción, `keyboard.js` llama al exe con `emit` y un argumento. El exe usa `SendKeys.SendWait(...)` para ejecutar la secuencia.
- También existe la acción `clipboard` que copia texto al portapapeles llamando al exe con `clipboard`.

- Pausas dentro de una acción: puedes insertar tokens inline `{WAIT:ms}` dentro del `value`/`action` para indicar una espera en milisegundos entre partes.
  - Ejemplo: `{ "key": "H", "action": "Hola{WAIT:2000}Mundo" }` → escribe `Hola`, espera 2000 ms, escribe `Mundo`.

## Definir macros (ejemplos)

La configuración se especifica en `config.json` (ver ejemplo abajo). `macroMap` acepta entradas en estos formatos:

- `{ "key": "T", "action": "Hola mundo" }` — se interpreta como `{ "key": "T", type: 'emit', value: 'Hola mundo' }`.
- `{ "key": "Y", "type": "clipboard", "value": "Texto copiado" }` — copia al portapapeles.
- `{ "key": "U", "type": "emit", "value": "^c" }` — envía Ctrl+C.

Ejemplos:

- Escribir texto: `{ "key": "T", "action": "Hola mundo" }` (o `{ "key": "T", "type": "emit", "value": "Hola mundo" }`)
- Copiar al portapapeles: `{ "key": "Y", "type": "clipboard", "value": "Texto copiado" }`
- Enviar pulsaciones (SendKeys): `{ "key": "U", "type": "emit", "value": "^c" }` (envía Ctrl+C)

## Sintaxis para `emit` (SendKeys)

`SendKeys` usa una sintaxis concreta para representar teclas especiales y modificadores. Aquí los más útiles:

- Modificadores:
  - `^` = Ctrl
  - `%` = Alt
  - `+` = Shift

- Teclas especiales (escribir literalmente entre llaves):
  - `{ENTER}` = Enter
  - `{TAB}` = Tab
  - `{ESC}` = Escape
  - `{BACKSPACE}` o `{BS}` = Backspace
  - `{DELETE}` = Supr
  - `{HOME}`, `{END}`
  - `{LEFT}`, `{RIGHT}`, `{UP}`, `{DOWN}` = flechas
  - `{PGUP}`, `{PGDN}` = PageUp/PageDown
  - `{F1}` ... `{F12}`

- Repetir una tecla: `{RIGHT 3}` envía la flecha derecha 3 veces.
- Para enviar literalmente `^%+{}` caracteres hay que escaparlos.

Ejemplos concretos de `value` para `emit`:

- `"Hola mundo"` → escribe texto
- `"^c"` → envía Ctrl+C (forma recomendada). Nota: `SendKeys` interpreta `^` como Ctrl inmediatamente antes de la tecla; no es necesario poner la letra entre llaves — escribir "^{c}" puede ser confuso o no funcionar.
- `"{UP}"` → flecha arriba
- `"{DOWN 2}"` → flecha abajo dos veces
- `"^%{ESC}"` → Ctrl+Alt+Esc (aunque SendKeys puede no funcionar con la tecla Win)

**Limitaciones**:

- `SendKeys` no soporta la tecla Windows (`LWIN`/`RWIN`). Si necesitas emular combos con la tecla Win, habría que implementar envío con `SendInput`/`SendInput` nativo.
- Algunas aplicaciones elevadas/seguras pueden ignorar entradas sintetizadas por `SendKeys`.

## Ejemplos completos de `macroMap`

```js
const macroMap = [
  {key: 'T', action: 'Hola mundo'},
  {key: 'U', type: 'emit', value: '{UP}{UP}{ENTER}'},
  {key: 'I', type: 'emit', value: '^c'}, // Ctrl+C
  {key: 'Y', type: 'clipboard', value: 'Texto copiado al portapapeles'},
];
```

## Comportamiento del listener

- Cuando pulsas la combinación de modificadores definida en `listenerMods` seguida de una letra, el listener marca la letra y, al soltarla, espera a que los modificadores configurados se liberen. Comprueba el estado de los modificadores periódicamente (poll cada 50 ms) y emite la tecla a stdout en cuanto detecta que los modificadores ya no están pulsados. Esto evita enviar la pulsación mientras los modificadores siguen activos.

## Notas finales

- Para combos complejos que incluyan la tecla Windows o necesiten máxima fiabilidad, se puede extender el exe para usar `SendInput` nativo; dímelo y lo implemento.
- Para combos complejos que incluyan la tecla Windows o necesiten máxima fiabilidad, se puede extender el exe para usar `SendInput` nativo; dímelo y lo implemento.
- Si quieres otro formato (por ejemplo JSON con tipo/valor en vez de un solo argumento), puedo cambiar el protocolo entre JS y el exe.

## Ejemplo de `config.jsonc`

```json
{
  "listenerMods": "CTRL+ALT+WIN",
  "macroMap": [
    {"key": "T", "action": "Hola mundo"},
    {"key": "H", "action": "Hola{WAIT:2000}Mundo"},
    {"key": "Y", "type": "clipboard", "value": "Texto copiado al portapapeles"},
    {"key": "I", "type": "emit", "value": "{UP}{UP}{ENTER}"}
  ]
}
```
